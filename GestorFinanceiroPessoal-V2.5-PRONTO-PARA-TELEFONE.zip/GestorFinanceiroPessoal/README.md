# Gestor Financeiro Pessoal — V2.5

Projeto Android nativo em Kotlin + Jetpack Compose.

## Build no telefone

Este projeto está preparado para ser aberto em um IDE Android no próprio aparelho, como o AndroidIDE. O projeto usa Android Gradle Plugin 8.6.1, Kotlin 2.0.21 e Gradle 8.7.

O arquivo `LEIA_PRIMEIRO_NO_TELEFONE.txt` contém o procedimento passo a passo.

## Recursos
- Contas e movimentos locais.
- Dívidas.
- Cartões e parcelamentos.
- Orçamentos.
- Metas.
- Assistente financeiro.
- Reconhecimento de voz.

## Saída esperada
Após um build de debug bem-sucedido:
`app/build/outputs/apk/debug/app-debug.apk`
