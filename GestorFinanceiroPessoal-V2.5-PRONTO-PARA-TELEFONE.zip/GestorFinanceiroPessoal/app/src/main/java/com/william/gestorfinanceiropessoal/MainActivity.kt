package com.william.gestorfinanceiropessoal

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Conta(
    val id: Long,
    val nome: String,
    val saldoInicial: Double
)

data class Divida(
    val id: Long,
    val nome: String,
    val valorTotal: Double,
    val valorPago: Double = 0.0,
    val jurosMensais: Double = 0.0,
    val parcelaMensal: Double = 0.0
) {
    val saldo get() = (valorTotal - valorPago).coerceAtLeast(0.0)
}

data class Cartao(
    val id: Long,
    val nome: String,
    val limite: Double,
    val fechamentoDia: Int,
    val vencimentoDia: Int
)

data class CompraParcelada(
    val id: Long,
    val cartaoId: Long,
    val descricao: String,
    val valorTotal: Double,
    val parcelas: Int,
    val parcelaAtual: Int = 0
) {
    val valorParcela get() = valorTotal / parcelas.coerceAtLeast(1)
    val restantes get() = (parcelas - parcelaAtual).coerceAtLeast(0)
    val comprometido get() = valorParcela * restantes
}

data class Orcamento(
    val id: Long,
    val categoria: String,
    val limiteMensal: Double
)

data class Meta(
    val id: Long,
    val nome: String,
    val valorAlvo: Double,
    val valorAtual: Double = 0.0
) {
    val progresso get() = (valorAtual / valorAlvo.coerceAtLeast(1.0)).coerceIn(0.0, 1.0)
}

data class Movimento(
    val id: Long,
    val descricao: String,
    val valor: Double,
    val entrada: Boolean,
    val categoria: String,
    val contaId: Long,
    val formaPagamento: String = "",
    val data: Long = System.currentTimeMillis()
)

class FinanceRepository(context: Context) {
    private val prefs = context.getSharedPreferences("financeiro", Context.MODE_PRIVATE)

    fun contas(): List<Conta> {
        val raw = prefs.getString("contas", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Conta(o.getLong("id"), o.getString("nome"), o.getDouble("saldoInicial"))
            }
        }.getOrDefault(emptyList())
    }

    fun orcamentos(): List<Orcamento> {
        val raw = prefs.getString("orcamentos", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Orcamento(o.getLong("id"), o.getString("categoria"), o.getDouble("limiteMensal"))
            }
        }.getOrDefault(emptyList())
    }

    fun metas(): List<Meta> {
        val raw = prefs.getString("metas", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Meta(o.getLong("id"), o.getString("nome"), o.getDouble("valorAlvo"), o.optDouble("valorAtual", 0.0))
            }
        }.getOrDefault(emptyList())
    }

    fun salvarOrcamentos(lista: List<Orcamento>) {
        val arr = JSONArray()
        lista.forEach { o -> arr.put(JSONObject().apply {
            put("id", o.id); put("categoria", o.categoria); put("limiteMensal", o.limiteMensal)
        }) }
        prefs.edit().putString("orcamentos", arr.toString()).apply()
    }

    fun salvarMetas(lista: List<Meta>) {
        val arr = JSONArray()
        lista.forEach { m -> arr.put(JSONObject().apply {
            put("id", m.id); put("nome", m.nome); put("valorAlvo", m.valorAlvo); put("valorAtual", m.valorAtual)
        }) }
        prefs.edit().putString("metas", arr.toString()).apply()
    }

    fun cartoes(): List<Cartao> {
        val raw = prefs.getString("cartoes", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Cartao(
                    o.getLong("id"),
                    o.getString("nome"),
                    o.getDouble("limite"),
                    o.optInt("fechamentoDia", 1),
                    o.optInt("vencimentoDia", 10)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun comprasParceladas(): List<CompraParcelada> {
        val raw = prefs.getString("parceladas", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                CompraParcelada(
                    o.getLong("id"),
                    o.getLong("cartaoId"),
                    o.getString("descricao"),
                    o.getDouble("valorTotal"),
                    o.getInt("parcelas"),
                    o.optInt("parcelaAtual", 0)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun salvarCartoes(lista: List<Cartao>) {
        val arr = JSONArray()
        lista.forEach { c -> arr.put(JSONObject().apply {
            put("id", c.id); put("nome", c.nome); put("limite", c.limite)
            put("fechamentoDia", c.fechamentoDia); put("vencimentoDia", c.vencimentoDia)
        }) }
        prefs.edit().putString("cartoes", arr.toString()).apply()
    }

    fun salvarParceladas(lista: List<CompraParcelada>) {
        val arr = JSONArray()
        lista.forEach { c -> arr.put(JSONObject().apply {
            put("id", c.id); put("cartaoId", c.cartaoId); put("descricao", c.descricao)
            put("valorTotal", c.valorTotal); put("parcelas", c.parcelas)
            put("parcelaAtual", c.parcelaAtual)
        }) }
        prefs.edit().putString("parceladas", arr.toString()).apply()
    }

    fun dividas(): List<Divida> {
        val raw = prefs.getString("dividas", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Divida(
                    o.getLong("id"),
                    o.getString("nome"),
                    o.getDouble("valorTotal"),
                    o.optDouble("valorPago", 0.0),
                    o.optDouble("jurosMensais", 0.0),
                    o.optDouble("parcelaMensal", 0.0)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun salvarDividas(lista: List<Divida>) {
        val arr = JSONArray()
        lista.forEach { d ->
            arr.put(JSONObject().apply {
                put("id", d.id)
                put("nome", d.nome)
                put("valorTotal", d.valorTotal)
                put("valorPago", d.valorPago)
                put("jurosMensais", d.jurosMensais)
                put("parcelaMensal", d.parcelaMensal)
            })
        }
        prefs.edit().putString("dividas", arr.toString()).apply()
    }

    fun movimentos(): List<Movimento> {
        val raw = prefs.getString("movimentos", null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Movimento(
                    o.getLong("id"),
                    o.getString("descricao"),
                    o.getDouble("valor"),
                    o.getBoolean("entrada"),
                    o.getString("categoria"),
                    o.getLong("contaId"),
                    o.optString("formaPagamento", ""),
                    o.optLong("data", System.currentTimeMillis())
                )
            }
        }.getOrDefault(emptyList())
    }

    fun salvarContas(lista: List<Conta>) {
        val arr = JSONArray()
        lista.forEach { c ->
            arr.put(JSONObject().apply {
                put("id", c.id)
                put("nome", c.nome)
                put("saldoInicial", c.saldoInicial)
            })
        }
        prefs.edit().putString("contas", arr.toString()).apply()
    }

    fun salvarMovimentos(lista: List<Movimento>) {
        val arr = JSONArray()
        lista.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id)
                put("descricao", m.descricao)
                put("valor", m.valor)
                put("entrada", m.entrada)
                put("categoria", m.categoria)
                put("contaId", m.contaId)
                put("formaPagamento", m.formaPagamento)
                put("data", m.data)
            })
        }
        prefs.edit().putString("movimentos", arr.toString()).apply()
    }
}

class FinanceViewModel(private val repo: FinanceRepository) : androidx.lifecycle.ViewModel() {
    var contas by mutableStateOf(repo.contas())
        private set
    var movimentos by mutableStateOf(repo.movimentos())
        private set
    var dividas by mutableStateOf(repo.dividas())
        private set
    var cartoes by mutableStateOf(repo.cartoes())
        private set
    var comprasParceladas by mutableStateOf(repo.comprasParceladas())
        private set
    var orcamentos by mutableStateOf(repo.orcamentos())
        private set
    var metas by mutableStateOf(repo.metas())
        private set

    fun adicionarConta(nome: String, saldoInicial: Double) {
        val conta = Conta(System.currentTimeMillis(), nome, saldoInicial)
        contas = contas + conta
        repo.salvarContas(contas)
    }

    fun adicionarMovimento(
        descricao: String,
        valor: Double,
        entrada: Boolean,
        categoria: String,
        contaId: Long,
        data: Long = System.currentTimeMillis(),
        formaPagamento: String = ""
    ) {
        val m = Movimento(
            System.currentTimeMillis(),
            descricao,
            valor,
            entrada,
            categoria.ifBlank { "Outros" },
            contaId,
            formaPagamento,
            data
        )
        movimentos = listOf(m) + movimentos
        repo.salvarMovimentos(movimentos)
    }

    fun adicionarOrcamento(categoria: String, limite: Double) {
        val o = Orcamento(System.currentTimeMillis(), categoria, limite)
        orcamentos = listOf(o) + orcamentos
        repo.salvarOrcamentos(orcamentos)
    }

    fun adicionarMeta(nome: String, alvo: Double) {
        val m = Meta(System.currentTimeMillis(), nome, alvo)
        metas = listOf(m) + metas
        repo.salvarMetas(metas)
    }

    fun adicionarAporteMeta(id: Long, valor: Double) {
        metas = metas.map {
            if (it.id == id) it.copy(valorAtual = (it.valorAtual + valor).coerceAtMost(it.valorAlvo))
            else it
        }
        repo.salvarMetas(metas)
    }

    fun gastoCategoria(categoria: String): Double =
        movimentos.filter { !it.entrada && it.categoria == categoria }.sumOf { it.valor }

    fun statusOrcamento(o: Orcamento): String {
        val gasto = gastoCategoria(o.categoria)
        return if (gasto > o.limiteMensal)
            "Acima do limite em ${brl(gasto - o.limiteMensal)}"
        else
            "Disponível: ${brl(o.limiteMensal - gasto)}"
    }

    fun adicionarCartao(nome: String, limite: Double, fechamento: Int, vencimento: Int) {
        val c = Cartao(System.currentTimeMillis(), nome, limite, fechamento, vencimento)
        cartoes = cartoes + c
        repo.salvarCartoes(cartoes)
    }

    fun adicionarCompraParcelada(cartaoId: Long, descricao: String, total: Double, parcelas: Int) {
        val c = CompraParcelada(System.currentTimeMillis(), cartaoId, descricao, total, parcelas)
        comprasParceladas = listOf(c) + comprasParceladas
        repo.salvarParceladas(comprasParceladas)
    }

    fun avancarParcela(id: Long) {
        comprasParceladas = comprasParceladas.map {
            if (it.id == id) it.copy(parcelaAtual = (it.parcelaAtual + 1).coerceAtMost(it.parcelas))
            else it
        }
        repo.salvarParceladas(comprasParceladas)
    }

    fun usadoCartao(cartao: Cartao): Double =
        comprasParceladas.filter { it.cartaoId == cartao.id }.sumOf { it.comprometido }

    fun disponivelCartao(cartao: Cartao): Double =
        (cartao.limite - usadoCartao(cartao)).coerceAtLeast(0.0)

    fun adicionarDivida(nome: String, total: Double, juros: Double, parcela: Double) {
        val d = Divida(System.currentTimeMillis(), nome, total, 0.0, juros, parcela)
        dividas = listOf(d) + dividas
        repo.salvarDividas(dividas)
    }

    fun pagarDivida(id: Long, valor: Double) {
        dividas = dividas.map {
            if (it.id == id) it.copy(valorPago = (it.valorPago + valor).coerceAtMost(it.valorTotal))
            else it
        }
        repo.salvarDividas(dividas)
    }

    fun totalEntradas(): Double = movimentos.filter { it.entrada }.sumOf { it.valor }
    fun totalGastos(): Double = movimentos.filter { !it.entrada }.sumOf { it.valor }
    fun totalDividas(): Double = dividas.sumOf { it.saldo }
    fun totalParceladoComprometido(): Double = comprasParceladas.sumOf { it.comprometido }

    fun diagnosticoFinanceiro(): List<String> {
        val entradas = totalEntradas()
        val gastos = totalGastos()
        val div = totalDividas()
        val parcelas = totalParceladoComprometido()
        val resultado = entradas - gastos
        val lista = mutableListOf<String>()

        if (entradas <= 0) {
            lista += "Cadastre suas entradas para que eu consiga calcular sua capacidade financeira."
            return lista
        }
        if (resultado < 0) {
            lista += "⚠️ Seus gastos registrados estão acima das entradas. A prioridade é reduzir gastos variáveis e evitar novas parcelas."
        } else {
            lista += "✅ Você está com saldo positivo nos registros: ${brl(resultado)}."
        }
        if (div > 0) {
            val prioridade = dividas.filter { it.saldo > 0 }.maxByOrNull { it.jurosMensais }
            if (prioridade != null && prioridade.jurosMensais > 0) {
                lista += "🎯 A dívida com maior juros é '${prioridade.nome}' (${prioridade.jurosMensais}% ao mês). Ela merece atenção prioritária."
            } else {
                lista += "🎯 Você tem ${brl(div)} em dívidas. Podemos comparar bola de neve e avalanche antes de decidir."
            }
        }
        if (parcelas > 0) {
            lista += "💳 Existem ${brl(parcelas)} em compromissos de compras parceladas futuras."
        }
        val limites = orcamentos.filter { gastoCategoria(it.categoria) > it.limiteMensal }
        if (limites.isNotEmpty()) {
            lista += "📊 Você ultrapassou o orçamento de: ${limites.joinToString { it.categoria }}."
        }
        if (metas.isNotEmpty()) {
            val meta = metas.maxByOrNull { it.progresso }
            if (meta != null) lista += "🎯 Sua meta '${meta.nome}' está em ${"%.0f".format(meta.progresso * 100)}%."
        }
        return lista
    }

    fun capacidadeExtraParaDividas(): Double =
        (totalEntradas() - totalGastos()).coerceAtLeast(0.0)

    fun responderPerguntaVoz(texto: String): String {
        val t = texto.lowercase(Locale("pt", "BR"))
        val perguntaPt = when {
            t.contains("cuánto puedo gastar") || t.contains("quanto posso gastar") -> "quanto posso gastar hoje?"
            t.contains("quanto gasto com comida") || t.contains("cuánto gasto con comida") -> "quanto gasto com alimentação?"
            t.contains("qual dívida devo pagar primeiro") || t.contains("qué deuda debo pagar primero") -> "qual dívida devo pagar primeiro?"
            t.contains("quanto falta") || t.contains("cuánto falta") -> "quanto falta para minhas metas?"
            else -> texto
        }
        return responderPergunta(perguntaPt)
    }

    fun responderPergunta(pergunta: String): String {
        val q = pergunta.lowercase(Locale("pt", "BR")).trim()
        return when {
            listOf("quanto posso gastar", "posso gastar hoje", "quanto gastar").any { q.contains(it) } -> {
                val saldo = capacidadeExtraParaDividas()
                "Com os registros atuais, sua margem positiva é ${brl(saldo)}. Antes de gastar, reserve o valor das contas e compromissos futuros que ainda não foram lançados."
            }
            listOf("gasto com comida", "gasto com alimentação", "alimentação", "alimentacao").any { q.contains(it) } -> {
                "Seus gastos registrados em Alimentação são ${brl(gastoCategoria("Alimentação"))}."
            }
            listOf("dívida primeiro", "divida primeiro", "qual dívida", "qual divida").any { q.contains(it) } -> {
                val d = dividas.filter { it.saldo > 0 }.maxByOrNull { it.jurosMensais }
                if (d != null) "Minha primeira sugestão é analisar '${d.nome}', que tem ${d.jurosMensais}% de juros mensais e saldo de ${brl(d.saldo)}."
                else "Você ainda não cadastrou dívidas abertas."
            }
            listOf("guardar", "economizar", "juntar").any { q.contains(it) } -> {
                "Você tem ${brl(metas.sumOf { it.valorAlvo - it.valorAtual })} restantes para alcançar suas metas cadastradas."
            }
            else -> "Posso analisar entradas, gastos, dívidas, parcelamentos, orçamentos e metas. Tente perguntar: “quanto posso gastar?”, “qual dívida devo pagar primeiro?” ou “quanto gasto com alimentação?”"
        }
    }

    fun simulacaoDivida(divida: Divida, extraMensal: Double): String {
        val saldo = divida.saldo
        val pagamento = divida.parcelaMensal + extraMensal
        if (saldo <= 0) return "Esta dívida já está quitada."
        if (pagamento <= 0) return "Informe uma parcela mensal ou um valor extra maior que zero."
        val taxa = divida.jurosMensais / 100.0
        if (taxa <= 0) {
            val meses = kotlin.math.ceil(saldo / pagamento).toInt()
            return "Sem juros informados: aproximadamente $meses meses."
        }
        var restante = saldo
        var meses = 0
        while (restante > 0 && meses < 600) {
            restante *= (1 + taxa)
            restante -= pagamento
            meses++
            if (restante > saldo * 10) break
        }
        return if (restante <= 0) "Aproximadamente $meses meses."
        else "O pagamento informado não cobre os juros; precisamos aumentar o valor mensal."
    }

    fun saldoConta(conta: Conta): Double {
        val movimentosDaConta = movimentos.filter { it.contaId == conta.id }
        return conta.saldoInicial +
            movimentosDaConta.filter { it.entrada }.sumOf { it.valor } -
            movimentosDaConta.filter { !it.entrada }.sumOf { it.valor }
    }

    val saldoTotal get() = contas.sumOf { saldoConta(it) }
    val entradas get() = movimentos.filter { it.entrada }.sumOf { it.valor }
    val gastos get() = movimentos.filter { !it.entrada }.sumOf { it.valor }
}

private fun brl(v: Double): String =
    NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(v)


data class VozInterpretada(
    val descricao: String,
    val valor: Double,
    val entrada: Boolean,
    val categoria: String
)

fun interpretarVoz(texto: String): VozInterpretada? {
    val t = texto.lowercase(Locale("pt", "BR")).trim()
    val numeroRegex = Regex("""(?:r\$?\s*)?(\d+(?:[.,]\d{1,2})?)\s*(?:reais?|rs)\b""")
    val valorMatch = numeroRegex.find(t) ?: Regex("""(?:r\$?\s*)?(\d+(?:[.,]\d{1,2})?)\b""").find(t)
    val valor = valorMatch?.groupValues?.getOrNull(1)
        ?.replace(".", "")
        ?.replace(",", ".")
        ?.toDoubleOrNull() ?: return null

    val entrada = listOf(
        "recebi", "ganhei", "entrou", "recebido", "salário", "salario",
        "receita", "recebi um", "recebi uma", "recebi de"
    ).any { t.contains(it) }

    val formaPagamento = when {
        listOf("pix").any { t.contains(it) } -> "Pix"
        listOf("cartão", "cartao", "crédito", "credito").any { t.contains(it) } -> "Cartão"
        listOf("débito", "debito").any { t.contains(it) } -> "Débito"
        listOf("dinheiro", "em espécie", "em especie").any { t.contains(it) } -> "Dinheiro"
        else -> ""
    }

    val categoria = when {
        listOf("sorvete", "comida", "almoço", "almoco", "jantar", "lanche", "restaurante", "mercado", "supermercado").any { t.contains(it) } -> "Alimentação"
        listOf("uber", "99", "ônibus", "onibus", "gasolina", "combustível", "combustivel", "transporte").any { t.contains(it) } -> "Transporte"
        listOf("luz", "energia", "água", "agua", "internet", "telefone", "aluguel", "renda").any { t.contains(it) } -> "Contas"
        listOf("camisa", "roupa", "calça", "calca", "sapato", "vestido").any { t.contains(it) } -> "Vestuário"
        else -> if (entrada) "Receitas" else "Outros"
    }

    val descricao = when {
        t.contains("sorvete") -> "Sorvete"
        t.contains("uber") -> "Uber"
        t.contains("supermercado") -> "Supermercado"
        t.contains("mercado") -> "Mercado"
        t.contains("aluguel") -> "Aluguel"
        t.contains("luz") || t.contains("energia") -> "Conta de luz"
        t.contains("salário") || t.contains("salario") -> "Salário"
        t.contains("gorjeta") -> "Gorjeta"
        else -> texto.replaceFirstChar { it.uppercase() }.take(60)
    }

    return VozInterpretada(descricao, valor, entrada, categoria)
}

class MainActivity : ComponentActivity() {
    private val pedirMicrofone = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { concedida ->
        if (!concedida) {
            android.widget.Toast.makeText(
                this,
                "Permissão do microfone não concedida.",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
        }
        setContent { FinanceApp(FinanceRepository(this)) }
    }
}

@Composable
fun FinanceApp(repo: FinanceRepository) {
    val vm = remember { FinanceViewModel(repo) }
    var tela by remember { mutableStateOf("inicio") }
    var novoMovimento by remember { mutableStateOf(false) }
    var filtroCategoria by remember { mutableStateOf("Todas") }
    var mostrarVoz by remember { mutableStateOf(false) }
    var novaConta by remember { mutableStateOf(false) }
    var novaDivida by remember { mutableStateOf(false) }
    var novoCartao by remember { mutableStateOf(false) }
    var novaCompra by remember { mutableStateOf(false) }
    var novoOrcamento by remember { mutableStateOf(false) }
    var novaMeta by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Gestor Financeiro Pessoal") }) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tela == "inicio", { tela = "inicio" }, icon = { Text("🏠") }, label = { Text("Início") })
                    NavigationBarItem(tela == "contas", { tela = "contas" }, icon = { Text("🏦") }, label = { Text("Contas") })
                    NavigationBarItem(tela == "movimentos", { tela = "movimentos" }, icon = { Text("💸") }, label = { Text("Movimentos") })
                    NavigationBarItem(tela == "dividas", { tela = "dividas" }, icon = { Text("💳") }, label = { Text("Dívidas") })
                    NavigationBarItem(tela == "cartoes", { tela = "cartoes" }, icon = { Text("💰") }, label = { Text("Cartões") })
                    NavigationBarItem(tela == "orcamentos", { tela = "orcamentos" }, icon = { Text("📊") }, label = { Text("Orçamentos") })
                    NavigationBarItem(tela == "metas", { tela = "metas" }, icon = { Text("🎯") }, label = { Text("Metas") })
                    NavigationBarItem(tela == "assistente", { tela = "assistente" }, icon = { Text("🤖") }, label = { Text("Assistente") })
                }
            },
            floatingActionButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FloatingActionButton(onClick = { mostrarVoz = true }) { Text("🎤") }
                    FloatingActionButton(onClick = {
                        if (tela == "contas") novaConta = true
                    else if (tela == "dividas") novaDivida = true
                    else if (tela == "cartoes") novoCartao = true
                    else if (tela == "orcamentos") novoOrcamento = true
                    else if (tela == "metas") novaMeta = true
                    else novoMovimento = true
                    }) { Text("+") }
                }
            }
        ) { padding ->
            when (tela) {
                "contas" -> ContasScreen(vm, Modifier.padding(padding))
                "movimentos" -> MovimentosScreen(
                    vm,
                    filtroCategoria,
                    { filtroCategoria = it },
                    Modifier.padding(padding)
                )
                "dividas" -> DividasScreen(vm, Modifier.padding(padding))
                "cartoes" -> CartoesScreen(vm, Modifier.padding(padding))
                "orcamentos" -> OrcamentosScreen(vm, Modifier.padding(padding))
                "metas" -> MetasScreen(vm, Modifier.padding(padding))
                "assistente" -> AssistenteScreen(vm, Modifier.padding(padding), onPedirMicrofone)
                "inicio" -> DashboardScreen(vm, Modifier.padding(padding))
                else -> DashboardScreen(vm, Modifier.padding(padding))
            }
        }

        if (novaConta) {
            NovaContaDialog(
                onDismiss = { novaConta = false },
                onSave = { nome, saldo ->
                    vm.adicionarConta(nome, saldo)
                    novaConta = false
                }
            )
        }

        if (novoMovimento) {
            NovoMovimentoDialog(
                contas = vm.contas,
                onDismiss = { novoMovimento = false },
                onSave = { d, v, e, c, conta, data, pagamento ->
                    vm.adicionarMovimento(d, v, e, c, conta, data, pagamento)
                    novoMovimento = false
                }
            )
        }
        if (mostrarVoz) {
            VozDialog(
                contas = vm.contas,
                onDismiss = { mostrarVoz = false },
                onSave = { d, v, e, c, conta ->
                    vm.adicionarMovimento(d, v, e, c, conta)
                    mostrarVoz = false
                }
            )
        }
        if (novaDivida) {
            NovaDividaDialog(
                onDismiss = { novaDivida = false },
                onSave = { nome, total, juros, parcela ->
                    vm.adicionarDivida(nome, total, juros, parcela)
                    novaDivida = false
                }
            )
        }
        if (novoCartao) {
            NovoCartaoDialog(
                onDismiss = { novoCartao = false },
                onSave = { nome, limite, fechamento, vencimento ->
                    vm.adicionarCartao(nome, limite, fechamento, vencimento)
                    novoCartao = false
                }
            )
        }
        if (novoOrcamento) {
            NovoOrcamentoDialog(
                onDismiss = { novoOrcamento = false },
                onSave = { categoria, limite ->
                    vm.adicionarOrcamento(categoria, limite)
                    novoOrcamento = false
                }
            )
        }
        if (novaMeta) {
            NovaMetaDialog(
                onDismiss = { novaMeta = false },
                onSave = { nome, alvo ->
                    vm.adicionarMeta(nome, alvo)
                    novaMeta = false
                }
            )
        }
    }
}


@Composable
fun DashboardScreen(vm: FinanceViewModel, modifier: Modifier = Modifier) {
    val entradas = vm.totalEntradas()
    val gastos = vm.totalGastos()
    val dividas = vm.totalDividas()
    val parcelado = vm.totalParceladoComprometido()
    val saldo = entradas - gastos

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Visão geral", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Saldo dos registros", style = MaterialTheme.typography.titleMedium)
                Text(brl(saldo), style = MaterialTheme.typography.headlineMedium)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Card(Modifier.weight(1f)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Entradas")
                    Text(brl(entradas))
                }
            }
            Card(Modifier.weight(1f)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Gastos")
                    Text(brl(gastos))
                }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Compromissos", style = MaterialTheme.typography.titleMedium)
                Text("Dívidas abertas: ${brl(dividas)}")
                Text("Parcelamentos futuros: ${brl(parcelado)}")
                Text("Orçamentos acima do limite: ${vm.orcamentos.count { vm.gastoCategoria(it.categoria) > it.limiteMensal }}")
                Text("Metas: ${vm.metas.count { it.valorAtual < it.valorAlvo }} em andamento")
            }
        }
        Text("Situação", style = MaterialTheme.typography.titleMedium)
        vm.diagnosticoFinanceiro().take(3).forEach { Text(it) }
    }
}

@Composable
fun InicioScreen(vm: FinanceViewModel, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Resumo financeiro", style = MaterialTheme.typography.headlineSmall)
        Resumo("Saldo total", brl(vm.saldoTotal))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Resumo("Entradas", brl(vm.entradas), Modifier.weight(1f))
            Resumo("Gastos", brl(vm.gastos), Modifier.weight(1f))
        }
        Text("Minhas contas", style = MaterialTheme.typography.titleLarge)
        if (vm.contas.isEmpty()) Text("Nenhuma conta cadastrada. Toque em + na aba Contas.")
        vm.contas.forEach { conta ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(conta.nome)
                    Text(brl(vm.saldoConta(conta)))
                }
            }
        }
    }
}

@Composable
fun ContasScreen(vm: FinanceViewModel, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Minhas contas", style = MaterialTheme.typography.headlineSmall)
        Text("Toque em + para adicionar uma conta ou carteira.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.contas, key = { it.id }) { conta ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(conta.nome, style = MaterialTheme.typography.titleMedium)
                        Text(brl(vm.saldoConta(conta)), style = MaterialTheme.typography.headlineSmall)
                    }
                }
            }
        }
    }
}

@Composable
fun MovimentosScreen(vm: FinanceViewModel, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Movimentos", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.movimentos, key = { it.id }) { m ->
                val conta = vm.contas.firstOrNull { it.id == m.contaId }?.nome ?: "Sem conta"
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(m.descricao, style = MaterialTheme.typography.titleMedium)
                            Text(
    "${m.categoria} • $conta • ${m.formaPagamento.ifBlank { "Pagamento não informado" }} • ${SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(m.data))}",
    style = MaterialTheme.typography.bodySmall
)
                        }
                        Text(
                            (if (m.entrada) "+ " else "- ") + brl(m.valor),
                            color = if (m.entrada) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}


@Composable
fun VozDialog(
    contas: List<Conta>,
    onDismiss: () -> Unit,
    onSave: (String, Double, Boolean, String, Long) -> Unit
) {
    var ouvindo by remember { mutableStateOf(false) }
    var texto by remember { mutableStateOf("") }
    var interpretado by remember { mutableStateOf<VozInterpretada?>(null) }
    var erro by remember { mutableStateOf("") }
    var contaId by remember { mutableLongStateOf(contas.firstOrNull()?.id ?: -1L) }

    val context = androidx.compose.ui.platform.LocalContext.current

    fun iniciar() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            erro = "O reconhecimento de voz não está disponível neste aparelho."
            return
        }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { ouvindo = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { ouvindo = false }
            override fun onError(error: Int) {
                ouvindo = false
                erro = "Não foi possível reconhecer a fala. Verifique o microfone e tente novamente."
                recognizer.destroy()
            }
            override fun onResults(results: Bundle?) {
                ouvindo = false
                val lista = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                texto = lista?.firstOrNull().orEmpty()
                interpretado = interpretarVoz(texto)
                if (interpretado == null) erro = "Entendi a frase, mas não consegui identificar o valor."
                else {
                    contas.firstOrNull { c -> texto.contains(c.nome, ignoreCase = true) }?.let {
                        contaId = it.id
                    }
                }
                recognizer.destroy()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            if (android.os.Build.VERSION.SDK_INT >= 34) {
                putExtra("android.speech.extra.ENABLE_LANGUAGE_DETECTION", true)
            }
        }
        try {
            recognizer.startListening(intent)
        } catch (_: SecurityException) {
            erro = "Permissão do microfone não concedida."
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar por voz") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Fale em português ou espanhol. Exemplo:")
                Text("“Compré un helado por veinte reales.”")
                Button(
                    onClick = {
                        if (androidx.core.content.ContextCompat.checkSelfPermission(
                                context, Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                        ) iniciar()
                        else erro = "Conceda a permissão do microfone nas configurações do Android."
                    },
                    enabled = !ouvindo
                ) { Text(if (ouvindo) "🎤 Escutando..." else "🎤 Falar") }

                if (texto.isNotBlank()) Text("Você disse: $texto")
                interpretado?.let { x ->
                    Text("Resultado:", style = MaterialTheme.typography.titleMedium)
                    Text("${x.descricao} • R$ ${"%.2f".format(Locale.US, x.valor)}")
                    Text("Categoria: ${x.categoria}")
                    val forma = when {
                        texto.contains("pix", ignoreCase = true) -> "Pix"
                        texto.contains("cartão", ignoreCase = true) || texto.contains("cartao", ignoreCase = true) -> "Cartão"
                        texto.contains("débito", ignoreCase = true) || texto.contains("debito", ignoreCase = true) -> "Débito"
                        texto.contains("dinheiro", ignoreCase = true) -> "Dinheiro"
                        else -> "Não informado"
                    }
                    Text("Pagamento: $forma")
                    Text(if (x.entrada) "Tipo: Entrada" else "Tipo: Gasto")

                    if (contas.isNotEmpty()) {
                        OutlinedTextField(
                        pagamento,
                        { pagamento = it },
                        label = { Text("Pagamento (Pix, Cartão, Dinheiro...)") },
                        singleLine = true
                    )
                    Text("Conta: ${contas.firstOrNull { it.id == contaId }?.nome ?: ""}")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            contas.forEach { c ->
                                AssistChip(
                                    onClick = { contaId = c.id },
                                    label = { Text(c.nome) },
                                    leadingIcon = if (c.id == contaId) ({ Text("✓") }) else null
                                )
                            }
                        }
                    }
                }
                if (erro.isNotBlank()) Text(erro, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(
                enabled = interpretado != null && contas.isNotEmpty(),
                onClick = {
                    val x = interpretado ?: return@TextButton
                    onSave(x.descricao, x.valor, x.entrada, x.categoria, contaId)
                }
            ) { Text("Registrar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}


@Composable
fun DividasScreen(vm: FinanceViewModel, modifier: Modifier = Modifier) {
    val total = vm.dividas.sumOf { it.saldo }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Dívidas", style = MaterialTheme.typography.headlineSmall)
        Text("Saldo total das dívidas: ${brl(total)}")
        if (vm.dividas.isEmpty()) {
            Text("Nenhuma dívida cadastrada.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.dividas, key = { it.id }) { d ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(d.nome, style = MaterialTheme.typography.titleMedium)
                            Text("Saldo: ${brl(d.saldo)}")
                            Text("Total: ${brl(d.valorTotal)} • Pago: ${brl(d.valorPago)}")
                            if (d.jurosMensais > 0) Text("Juros: ${d.jurosMensais}% ao mês")
                            if (d.parcelaMensal > 0) Text("Parcela: ${brl(d.parcelaMensal)}")
                            if (d.saldo > 0) {
                                TextButton(onClick = { vm.pagarDivida(d.id, d.parcelaMensal.coerceAtMost(d.saldo)) }) {
                                    Text("Registrar próxima parcela")
                                }
                            } else {
                                Text("✅ Dívida quitada", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NovaDividaDialog(
    onDismiss: () -> Unit,
    onSave: (String, Double, Double, Double) -> Unit
) {
    var nome by remember { mutableStateOf("") }
    var total by remember { mutableStateOf("") }
    var juros by remember { mutableStateOf("") }
    var parcela by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova dívida") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(nome, { nome = it }, label = { Text("Nome") }, singleLine = true)
                OutlinedTextField(total, { total = it }, label = { Text("Valor total (R$)") }, singleLine = true)
                OutlinedTextField(juros, { juros = it }, label = { Text("Juros mensais (%)") }, singleLine = true)
                OutlinedTextField(parcela, { parcela = it }, label = { Text("Parcela mensal (R$)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val t = total.replace(",", ".").toDoubleOrNull()
                val j = juros.replace(",", ".").toDoubleOrNull() ?: 0.0
                val p = parcela.replace(",", ".").toDoubleOrNull() ?: 0.0
                if (nome.isNotBlank() && t != null && t > 0) onSave(nome.trim(), t, j, p)
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}


@Composable
fun CartoesScreen(vm: FinanceViewModel, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Cartões de crédito", style = MaterialTheme.typography.headlineSmall)
        if (vm.cartoes.isEmpty()) {
            Text("Nenhum cartão cadastrado. Toque em + para adicionar.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.cartoes, key = { it.id }) { c ->
                    val usado = vm.usadoCartao(c)
                    val disponivel = vm.disponivelCartao(c)
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(c.nome, style = MaterialTheme.typography.titleMedium)
                            Text("Limite: ${brl(c.limite)}")
                            Text("Comprometido: ${brl(usado)}")
                            Text("Disponível: ${brl(disponivel)}")
                            Text("Fechamento: dia ${c.fechamentoDia} • Vencimento: dia ${c.vencimentoDia}")
                            Button(onClick = { /* próxima etapa: compra parcelada */ }) {
                                Text("Adicionar compra parcelada")
                            }
                            vm.comprasParceladas.filter { it.cartaoId == c.id }.forEach { compra ->
                                Text(
                                    "${compra.descricao}: ${compra.parcelaAtual}/${compra.parcelas} • ${brl(compra.valorParcela)}"
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NovoCartaoDialog(
    onDismiss: () -> Unit,
    onSave: (String, Double, Int, Int) -> Unit
) {
    var nome by remember { mutableStateOf("") }
    var limite by remember { mutableStateOf("") }
    var fechamento by remember { mutableStateOf("1") }
    var vencimento by remember { mutableStateOf("10") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Novo cartão") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(nome, { nome = it }, label = { Text("Nome") }, singleLine = true)
                OutlinedTextField(limite, { limite = it }, label = { Text("Limite (R$)") }, singleLine = true)
                OutlinedTextField(fechamento, { fechamento = it }, label = { Text("Dia de fechamento") }, singleLine = true)
                OutlinedTextField(vencimento, { vencimento = it }, label = { Text("Dia de vencimento") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val l = limite.replace(",", ".").toDoubleOrNull()
                val f = fechamento.toIntOrNull()
                val v = vencimento.toIntOrNull()
                if (nome.isNotBlank() && l != null && l > 0 && f in 1..31 && v in 1..31)
                    onSave(nome.trim(), l, f!!, v!!)
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}


@Composable
fun OrcamentosScreen(vm: FinanceViewModel, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Orçamentos", style = MaterialTheme.typography.headlineSmall)
        Text("Defina quanto pretende gastar por categoria no mês.")
        if (vm.orcamentos.isEmpty()) Text("Nenhum orçamento cadastrado. Toque em +.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.orcamentos, key = { it.id }) { o ->
                val gasto = vm.gastoCategoria(o.categoria)
                val proporcao = (gasto / o.limiteMensal.coerceAtLeast(1.0)).coerceIn(0.0, 1.0)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(o.categoria, style = MaterialTheme.typography.titleMedium)
                        Text("Limite: ${brl(o.limiteMensal)}")
                        Text("Gasto registrado: ${brl(gasto)}")
                        LinearProgressIndicator(
                            progress = { proporcao },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(vm.statusOrcamento(o))
                    }
                }
            }
        }
    }
}

@Composable
fun NovoOrcamentoDialog(onDismiss: () -> Unit, onSave: (String, Double) -> Unit) {
    var categoria by remember { mutableStateOf("Alimentação") }
    var limite by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Novo orçamento") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(categoria, { categoria = it }, label = { Text("Categoria") }, singleLine = true)
                OutlinedTextField(limite, { limite = it }, label = { Text("Limite mensal (R$)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = limite.replace(",", ".").toDoubleOrNull()
                if (categoria.isNotBlank() && v != null && v > 0) onSave(categoria.trim(), v)
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun MetasScreen(vm: FinanceViewModel, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Metas de economia", style = MaterialTheme.typography.headlineSmall)
        if (vm.metas.isEmpty()) Text("Nenhuma meta cadastrada. Toque em +.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.metas, key = { it.id }) { m ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(m.nome, style = MaterialTheme.typography.titleMedium)
                        Text("${brl(m.valorAtual)} de ${brl(m.valorAlvo)}")
                        LinearProgressIndicator(progress = { m.progresso }, modifier = Modifier.fillMaxWidth())
                        if (m.valorAtual < m.valorAlvo) {
                            TextButton(onClick = {
                                vm.adicionarAporteMeta(m.id, 50.0)
                            }) { Text("Adicionar R$ 50") }
                        } else {
                            Text("🎉 Meta alcançada!", color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NovaMetaDialog(onDismiss: () -> Unit, onSave: (String, Double) -> Unit) {
    var nome by remember { mutableStateOf("") }
    var alvo by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova meta") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(nome, { nome = it }, label = { Text("Nome da meta") }, singleLine = true)
                OutlinedTextField(alvo, { alvo = it }, label = { Text("Valor alvo (R$)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = alvo.replace(",", ".").toDoubleOrNull()
                if (nome.isNotBlank() && v != null && v > 0) onSave(nome.trim(), v)
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}


@Composable
fun AssistenteScreen(
    vm: FinanceViewModel,
    modifier: Modifier = Modifier,
    onPedirMicrofone: () -> Unit = {}
) {
    var extra by remember { mutableStateOf("100") }
    var selectedDebt by remember { mutableStateOf(vm.dividas.firstOrNull()?.id ?: -1L) }
    var pergunta by remember { mutableStateOf("") }
    var resposta by remember { mutableStateOf("") }
    var vozAberta by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Assistente Financeiro", style = MaterialTheme.typography.headlineSmall)
        Text("Análise baseada nos dados registrados no aplicativo.")

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Pergunte sobre suas finanças", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    pergunta,
                    { pergunta = it },
                    label = { Text("Ex.: Quanto posso gastar hoje?") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { resposta = vm.responderPergunta(pergunta) },
                        enabled = pergunta.isNotBlank()
                    ) { Text("Analisar") }
                    OutlinedButton(
                        onClick = {
                            onPedirMicrofone()
                            vozAberta = true
                        }
                    ) { Text("🎤 Voz") }
                }
                if (resposta.isNotBlank()) Text(resposta)
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Resumo", style = MaterialTheme.typography.titleMedium)
                Text("Entradas: ${brl(vm.totalEntradas())}")
                Text("Gastos: ${brl(vm.totalGastos())}")
                Text("Dívidas: ${brl(vm.totalDividas())}")
                Text("Parcelamentos futuros: ${brl(vm.totalParceladoComprometido())}")
                Text("Saldo dos registros: ${brl(vm.totalEntradas() - vm.totalGastos())}")
            }
        }

        Text("Recomendações", style = MaterialTheme.typography.titleMedium)
        vm.diagnosticoFinanceiro().forEach { Text(it) }

        if (vm.dividas.isNotEmpty()) {
            HorizontalDivider()
            Text("Simulador de pagamento", style = MaterialTheme.typography.titleMedium)
            val divida = vm.dividas.firstOrNull { it.id == selectedDebt } ?: vm.dividas.first()
            Text("Dívida: ${divida.nome} • Saldo ${brl(divida.saldo)}")
            OutlinedTextField(
                extra,
                { extra = it },
                label = { Text("Valor extra por mês (R$)") },
                singleLine = true
            )
            val extraValor = extra.replace(",", ".").toDoubleOrNull() ?: 0.0
            Text("Se adicionar ${brl(extraValor)} por mês: ${vm.simulacaoDivida(divida, extraValor)}")
            Text("Estratégia sugerida: priorizar a dívida com maior juros quando o objetivo for pagar menos juros totais.")
        }
    }

    if (vozAberta) {
        AssistenteVozDialog(
            onDismiss = { vozAberta = false },
            onResult = {
                pergunta = it
                resposta = vm.responderPerguntaVoz(it)
                vozAberta = false
            }
        )
    }
}


@Composable
fun AssistenteVozDialog(
    onDismiss: () -> Unit,
    onResult: (String) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var ouvindo by remember { mutableStateOf(false) }
    var texto by remember { mutableStateOf("") }
    var erro by remember { mutableStateOf("") }

    fun ouvir() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            erro = "O reconhecimento de voz não está disponível neste aparelho."
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { ouvindo = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { ouvindo = false }
            override fun onError(error: Int) {
                ouvindo = false
                erro = "Não consegui reconhecer a fala. Tente novamente."
                r.destroy()
            }
            override fun onResults(results: Bundle?) {
                ouvindo = false
                texto = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (texto.isBlank()) erro = "Nenhuma frase foi reconhecida."
                else onResult(texto)
                r.destroy()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        try { r.startListening(i) } catch (_: SecurityException) {
            erro = "Permissão de microfone não concedida."
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Perguntar por voz") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Fale em português ou espanhol.")
                Button(onClick = { ouvir() }, enabled = !ouvindo) {
                    Text(if (ouvindo) "🎤 Escutando..." else "🎤 Falar")
                }
                if (texto.isNotBlank()) Text("Você disse: $texto")
                if (erro.isNotBlank()) Text(erro, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
fun Resumo(titulo: String, valor: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp)) {
        Text(titulo, style = MaterialTheme.typography.labelMedium)
        Text(valor, style = MaterialTheme.typography.titleMedium)
    }}
}

@Composable
fun NovaContaDialog(onDismiss: () -> Unit, onSave: (String, Double) -> Unit) {
    var nome by remember { mutableStateOf("") }
    var saldo by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova conta") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(nome, { nome = it }, label = { Text("Nome") }, singleLine = true)
                OutlinedTextField(saldo, { saldo = it }, label = { Text("Saldo inicial (R$)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = saldo.replace(",", ".").toDoubleOrNull()
                if (nome.isNotBlank() && v != null && v >= 0) onSave(nome.trim(), v)
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun NovoMovimentoDialog(
    contas: List<Conta>,
    onDismiss: () -> Unit,
    onSave: (String, Double, Boolean, String, Long, Long, String) -> Unit
) {
    var descricao by remember { mutableStateOf("") }
    var valor by remember { mutableStateOf("") }
    var entrada by remember { mutableStateOf(false) }
    var categoria by remember { mutableStateOf("Alimentação") }
    var pagamento by remember { mutableStateOf("Não informado") }
    var contaId by remember { mutableLongStateOf(contas.firstOrNull()?.id ?: -1L) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Novo movimento") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (contas.isEmpty()) {
                    Text("Cadastre uma conta primeiro.")
                } else {
                    OutlinedTextField(descricao, { descricao = it }, label = { Text("Descrição") }, singleLine = true)
                    OutlinedTextField(valor, { valor = it }, label = { Text("Valor (R$)") }, singleLine = true)
                    OutlinedTextField(categoria, { categoria = it }, label = { Text("Categoria") }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(entrada, { entrada = it })
                        Text("É uma entrada")
                    }
                    OutlinedTextField(
                        pagamento,
                        { pagamento = it },
                        label = { Text("Pagamento (Pix, Cartão, Dinheiro...)") },
                        singleLine = true
                    )
                    Text("Conta: ${contas.firstOrNull { it.id == contaId }?.nome ?: ""}")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        contas.forEach { c ->
                            AssistChip(
                                onClick = { contaId = c.id },
                                label = { Text(c.nome) },
                                leadingIcon = if (c.id == contaId) ({ Text("✓") }) else null
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = valor.replace(",", ".").toDoubleOrNull()
                if (contas.isNotEmpty() && descricao.isNotBlank() && v != null && v > 0 && contaId > 0)
                    onSave(descricao.trim(), v, entrada, categoria.trim(), contaId, System.currentTimeMillis(), pagamento)
            }) { Text("Registrar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
